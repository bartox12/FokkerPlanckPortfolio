# Modeling the Evolution of Wealth: A Fokker–Planck PDE Approach to Portfolio Risk

**Course project — Partial Differential Equations**
Authors: *[REPLACE WITH YOUR NAME]* & Bartłomiej Mielcarz

---

## Overview

This project models the time evolution of a portfolio's wealth distribution by treating
wealth under geometric Brownian motion and propagating its probability density with the
**Fokker–Planck (forward Kolmogorov) equation**. The PDE is solved numerically with the
**Finite Difference Method** and the results are used to compute and compare portfolio
risk metrics (probability of reaching a goal, probability of loss, Value-at-Risk,
Expected Shortfall) across different asset allocations.

## Contents

| File | Description |
|------|-------------|
| `report.pdf` | The full written report (the graded PDF deliverable). |
| `report.tex` | LaTeX source of the report. |
| `fokker_planck_portfolio.ipynb` | Self-contained Jupyter notebook: full numerical pipeline with all code, outputs, and embedded figures. Runs top-to-bottom with no external project modules. |
| `fpe_core.py` | Clean, reusable numerical engine (Crank–Nicolson and FTCS solvers in log- and wealth-space, analytic log-normal benchmarks, risk-metric integrators, Monte-Carlo cross-check). |
| `figures/` | The six vector (PDF) figures embedded in the report. |

## Reproducing the results

Requirements: Python ≥ 3.10 with `numpy`, `scipy`, `matplotlib` (plus `jupyter` to run
the notebook).

```bash
# Run the analysis notebook end-to-end
jupyter nbconvert --to notebook --execute fokker_planck_portfolio.ipynb

# Or import the core engine directly
python -c "import fpe_core; help(fpe_core)"
```

To rebuild the report from source:

```bash
latexmk -pdf report.tex
```

## Numerical summary (reproduced by the notebook)

- Mass conservation: ∫ q dy = 1.000000.
- Scheme validation vs. exact log-normal solution: max|CN − exact| ≈ 1.8e-5,
  max|FTCS − exact| ≈ 1.4e-5 (N = 1601).
- Spatial convergence (Crank–Nicolson, fixed Δt): observed order ≈ 2.00.
- Risk metrics (FDM vs. closed form) agree to 4+ significant figures.

---

### Notes before submission

1. **Replace the author placeholder** in both `report.tex` (`\author{...}`) and the
   compiled `report.pdf` with your real full name.
2. **Rename the ZIP** `FPPR_2XXXXX.zip` so that `2XXXXX` is your actual Student ID,
   per the naming convention `ProjectInitial_StudentID.zip`.
3. Cross-check the contents against the **original project description (15 April 2026)**
   to confirm every required criterion is covered.
