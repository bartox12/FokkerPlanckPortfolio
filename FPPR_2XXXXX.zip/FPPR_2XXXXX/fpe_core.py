"""
fpe_core.py
===========
Core numerical engine for the project

    "Modeling the Evolution of Wealth:
     A Fokker-Planck PDE Approach to Portfolio Risk"

Contents
--------
1.  Portfolio moments from an asset-class covariance model.
2.  Closed-form (log-normal) reference solution and its risk metrics.
3.  A Crank-Nicolson finite-difference solver for the Fokker-Planck
    equation in log-wealth coordinates (constant-coefficient
    advection-diffusion form).
4.  An explicit FTCS solver, used only to *demonstrate* the stability
    (CFL) restriction of explicit schemes.
5.  A variable-coefficient Crank-Nicolson solver in wealth coordinates
    (the degenerate parabolic operator), used as an independent check.
6.  Risk metrics computed directly from a numerical terminal density.
7.  A Monte-Carlo sampler of terminal wealth (third, independent check).

The code is deliberately written so that the same routines can be reused
verbatim inside the accompanying Jupyter notebook.
"""

from __future__ import annotations
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu
from scipy.stats import norm

# numpy 2.x renamed trapz -> trapezoid; support both.
trapz = np.trapezoid if hasattr(np, "trapezoid") else np.trapz


# ======================================================================
# 1.  Portfolio moments
# ======================================================================
def cov_from_corr(sigmas, corr):
    """Covariance matrix from a vector of volatilities and a correlation matrix."""
    s = np.asarray(sigmas, dtype=float)
    R = np.asarray(corr, dtype=float)
    return np.outer(s, s) * R


def portfolio_moments(weights, mu_vec, cov):
    """Annualized portfolio drift mu_p and volatility sigma_p for given weights."""
    w = np.asarray(weights, dtype=float)
    mu_p = float(w @ np.asarray(mu_vec, dtype=float))
    var_p = float(w @ np.asarray(cov, dtype=float) @ w)
    return mu_p, float(np.sqrt(var_p))


# ======================================================================
# 2.  Closed-form log-normal reference
# ======================================================================
def logspace_gaussian(y, t, y0, nu, sigma):
    """
    Exact density of Y_t = ln W_t at time t, started from a point mass at
    y0 at t = 0.  Y solves dY = nu dt + sigma dB, so Y_t ~ N(y0 + nu t, sigma^2 t).
    """
    var = sigma**2 * t
    return np.exp(-(y - y0 - nu * t) ** 2 / (2.0 * var)) / np.sqrt(2.0 * np.pi * var)


def wealth_lognormal(w, t, w0, mu, sigma):
    """Exact density of W_t (log-normal) at time t, started from W_0 = w0."""
    m = np.log(w0) + (mu - 0.5 * sigma**2) * t
    v = sigma * np.sqrt(t)
    return np.exp(-(np.log(w) - m) ** 2 / (2.0 * v**2)) / (w * v * np.sqrt(2.0 * np.pi))


def analytic_metrics(t, w0, mu, sigma, goal, loss, alpha=0.05):
    """
    Closed-form risk metrics of terminal wealth W_t (log-normal).
    VaR/CVaR are taken on the *level* of wealth: VaR is the alpha-quantile of
    W_t, CVaR = E[W_t | W_t <= VaR].
    """
    m = np.log(w0) + (mu - 0.5 * sigma**2) * t
    v = sigma * np.sqrt(t)
    z = norm.ppf(alpha)
    var_q = np.exp(m + v * z)
    cvar = np.exp(m + 0.5 * v**2) * norm.cdf(z - v) / alpha
    return dict(
        mean=w0 * np.exp(mu * t),
        median=np.exp(m),
        mode=np.exp(m - v**2),
        P_goal=float(1.0 - norm.cdf((np.log(goal) - m) / v)),
        P_loss=float(norm.cdf((np.log(loss) - m) / v)),
        VaR=float(var_q),
        CVaR=float(cvar),
    )


# ======================================================================
# 3.  Crank-Nicolson solver in log-wealth coordinates
# ======================================================================
def cn_logspace(mu, sigma, w0, T,
                t0=0.05, y_lo=2.5, y_hi=3.0, Ny=2001, Nt=1000,
                snapshot_times=None):
    """
    Solve   q_t = -nu q_y + 1/2 sigma^2 q_yy   on  [y0 - y_lo, y0 + y_hi]
    with homogeneous Dirichlet data, by Crank-Nicolson.

    The scheme is started at a small time t0 > 0 from the *exact* narrow
    Gaussian (a regularized point mass at y0 = ln w0); this isolates the
    time-stepping error from delta-function regularization error, because
    the true solution started from that exact state at t0 is again the exact
    Gaussian at the final time.

    Returns
    -------
    y          : spatial grid (log-wealth)
    times      : time grid  (t0 ... T)
    q_T        : terminal density on y
    snaps      : dict {t: density on y} for requested snapshot_times
    info       : dict of discretization diagnostics
    """
    nu = mu - 0.5 * sigma**2
    y0 = np.log(w0)
    y = np.linspace(y0 - y_lo, y0 + y_hi, Ny)
    dy = y[1] - y[0]
    times = np.linspace(t0, T, Nt + 1)
    dt = times[1] - times[0]

    r = sigma**2 * dt / dy**2          # diffusion number
    s = nu * dt / dy                   # advection (Courant) number

    # Interior tridiagonal systems (Dirichlet zeros eliminate boundary rows).
    Ni = Ny - 2
    A = sparse.diags(
        [np.full(Ni - 1, -(r + s) / 4.0),
         np.full(Ni,      1.0 + r / 2.0),
         np.full(Ni - 1,  (s - r) / 4.0)],
        offsets=[-1, 0, 1], format="csc")
    B = sparse.diags(
        [np.full(Ni - 1,  (r + s) / 4.0),
         np.full(Ni,      1.0 - r / 2.0),
         np.full(Ni - 1,  (r - s) / 4.0)],
        offsets=[-1, 0, 1], format="csc")
    lu = splu(A)

    q = logspace_gaussian(y, t0, y0, nu, sigma)
    q[0] = q[-1] = 0.0

    # map snapshot times to step indices
    snap_idx = {}
    if snapshot_times is not None:
        for ts in snapshot_times:
            k = int(round((ts - t0) / dt))
            snap_idx[min(max(k, 0), Nt)] = ts
    snaps = {}
    if 0 in snap_idx:
        snaps[snap_idx[0]] = q.copy()

    qi = q[1:-1].copy()
    for n in range(1, Nt + 1):
        qi = lu.solve(B.dot(qi))
        if n in snap_idx:
            full = np.empty(Ny)
            full[0] = full[-1] = 0.0
            full[1:-1] = qi
            snaps[snap_idx[n]] = full

    q[1:-1] = qi
    info = dict(dy=dy, dt=dt, r=r, s=s, nu=nu, y0=y0,
                y_min=y[0], y_max=y[-1], Ny=Ny, Nt=Nt, t0=t0)
    return y, times, q, snaps, info


# ======================================================================
# 4.  Explicit FTCS solver (for the stability demonstration only)
# ======================================================================
def ftcs_logspace(mu, sigma, w0, T, t0, Ny, Nt, y_lo=2.5, y_hi=3.0):
    """Forward-time centered-space scheme; conditionally stable (r <= 1)."""
    nu = mu - 0.5 * sigma**2
    y0 = np.log(w0)
    y = np.linspace(y0 - y_lo, y0 + y_hi, Ny)
    dy = y[1] - y[0]
    dt = (T - t0) / Nt
    r = sigma**2 * dt / dy**2
    s = nu * dt / dy
    q = logspace_gaussian(y, t0, y0, nu, sigma)
    blew_up = False
    for _ in range(Nt):
        qn = q.copy()
        q[1:-1] = (qn[1:-1]
                   - 0.5 * s * (qn[2:] - qn[:-2])
                   + 0.5 * r * (qn[2:] - 2.0 * qn[1:-1] + qn[:-2]))
        q[0] = q[-1] = 0.0
        if not np.all(np.isfinite(q)) or np.max(np.abs(q)) > 1e6:
            blew_up = True
            break
    return y, q, r, blew_up


# ======================================================================
# 5.  Variable-coefficient Crank-Nicolson in wealth coordinates
# ======================================================================
def cn_wealthspace(mu, sigma, w0, T, t0,
                   x_lo_factor=0.30, x_hi_factor=3.0, Nx=1601, Nt=1500,
                   snapshot_times=None):
    """
    Solve the Fokker-Planck equation directly in wealth x:

        p_t = 1/2 sigma^2 x^2 p_xx + (2 sigma^2 - mu) x p_x + (sigma^2 - mu) p,

    a *degenerate* parabolic operator (diffusion vanishes as x -> 0).
    Used as an independent cross-check of the log-space solver.
    Uniform x-grid on [x_lo_factor*w0, x_hi_factor*w0], Dirichlet zeros,
    started from the exact log-normal at t0.
    """
    x = np.linspace(x_lo_factor * w0, x_hi_factor * w0, Nx)
    dx = x[1] - x[0]
    dt = (T - t0) / Nt
    xi = x[1:-1]

    a = 0.5 * sigma**2 * xi**2
    b = (2.0 * sigma**2 - mu) * xi
    c = (sigma**2 - mu)

    lo = a / dx**2 - b / (2.0 * dx)          # coeff of p_{j-1}
    di = -2.0 * a / dx**2 + c                 # coeff of p_j
    up = a / dx**2 + b / (2.0 * dx)          # coeff of p_{j+1}

    Ni = Nx - 2
    A = sparse.diags(
        [-(dt / 2.0) * lo[1:],
         1.0 - (dt / 2.0) * di,
         -(dt / 2.0) * up[:-1]],
        offsets=[-1, 0, 1], format="csc")
    B = sparse.diags(
        [(dt / 2.0) * lo[1:],
         1.0 + (dt / 2.0) * di,
         (dt / 2.0) * up[:-1]],
        offsets=[-1, 0, 1], format="csc")
    lu = splu(A)

    p = wealth_lognormal(x, t0, w0, mu, sigma)
    p[0] = p[-1] = 0.0

    snap_idx = {}
    if snapshot_times is not None:
        for ts in snapshot_times:
            k = int(round((ts - t0) / dt))
            snap_idx[min(max(k, 0), Nt)] = ts
    snaps = {}
    if 0 in snap_idx:
        snaps[snap_idx[0]] = p.copy()

    pi = p[1:-1].copy()
    for n in range(1, Nt + 1):
        pi = lu.solve(B.dot(pi))
        if n in snap_idx:
            full = np.empty(Nx)
            full[0] = full[-1] = 0.0
            full[1:-1] = pi
            snaps[snap_idx[n]] = full

    p[1:-1] = pi
    return x, p, snaps, dict(dx=dx, dt=dt, Nx=Nx, Nt=Nt)


# ======================================================================
# 6.  Risk metrics from a numerical (log-wealth) density
# ======================================================================
def numeric_metrics(y, q, goal, loss, alpha=0.05):
    """
    Risk metrics from a numerical density q(y) of log-wealth.
    The density is renormalized to unit mass for quantile computation;
    the raw mass is returned separately as a conservation diagnostic.
    """
    mass = float(trapz(q, y))
    qn = q / mass

    # cumulative distribution F(y) = P(Y <= y)
    cdf = np.concatenate([[0.0], np.cumsum(0.5 * (qn[1:] + qn[:-1]) * np.diff(y))])
    cdf /= cdf[-1]

    P_loss = float(np.interp(np.log(loss), y, cdf))
    P_goal = float(1.0 - np.interp(np.log(goal), y, cdf))

    yq = float(np.interp(alpha, cdf, y))          # alpha-quantile of Y
    VaR = float(np.exp(yq))

    # E[W 1_{W<=VaR}] via cumulative integral of e^y q(y)
    g = np.exp(y) * qn
    G = np.concatenate([[0.0], np.cumsum(0.5 * (g[1:] + g[:-1]) * np.diff(y))])
    EW_tail = float(np.interp(yq, y, G))
    CVaR = EW_tail / alpha

    mean = float(trapz(np.exp(y) * qn, y))
    median = float(np.exp(np.interp(0.5, cdf, y)))
    # Mode of the *wealth* density p(w) = q(ln w)/w.  Since w = e^y is
    # monotone, argmax_w p(w) = exp(argmax_y [q(y) e^{-y}]).
    mode = float(np.exp(y[int(np.argmax(qn * np.exp(-y)))]))

    return dict(mass=mass, mean=mean, median=median, mode=mode,
                P_goal=P_goal, P_loss=P_loss, VaR=VaR, CVaR=CVaR)


# ======================================================================
# 7.  Monte-Carlo sampler (third independent check)
# ======================================================================
def monte_carlo_terminal(mu, sigma, w0, T, n_paths=400_000, seed=20260618):
    """Exact-in-law GBM terminal sampler:  W_T = w0 exp((mu-sigma^2/2)T + sigma sqrt(T) Z)."""
    rng = np.random.default_rng(seed)
    z = rng.standard_normal(n_paths)
    return w0 * np.exp((mu - 0.5 * sigma**2) * T + sigma * np.sqrt(T) * z)
